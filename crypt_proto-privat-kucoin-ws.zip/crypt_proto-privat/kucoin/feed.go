package kucoin

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"crypt_proto/domain"

	"github.com/gorilla/websocket"
)

// KuCoin public WS docs (high-level):
// 1) POST https://api.kucoin.com/api/v1/bullet-public -> token + endpoints
// 2) Connect to wss endpoint: <endpoint>?token=<token>&connectId=<id>
// 3) Subscribe to /market/ticker:<SYMBOL> for best bid/ask.

type Feed struct {
	debug bool
}

func NewFeed(debug bool) *Feed { return &Feed{debug: debug} }

func (f *Feed) Name() string { return "KuCoin" }

func (f *Feed) dlog(format string, args ...any) {
	if f.debug {
		log.Printf(format, args...)
	}
}

// ==== REST: symbols map (concat -> "BASE-QUOTE") ====

type symbolsResp struct {
	Code string `json:"code"`
	Data []struct {
		Symbol        string `json:"symbol"`
		BaseCurrency  string `json:"baseCurrency"`
		QuoteCurrency string `json:"quoteCurrency"`
		EnableTrading bool   `json:"enableTrading"`
	} `json:"data"`
}

func loadSpotSymbolsMap(ctx context.Context) (concatToKucoin map[string]string, kucoinToConcat map[string]string, err error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, "https://api.kucoin.com/api/v2/symbols", nil)
	if err != nil {
		return nil, nil, err
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		b, _ := io.ReadAll(resp.Body)
		return nil, nil, fmt.Errorf("kucoin symbols http %d: %s", resp.StatusCode, string(b))
	}
	var sr symbolsResp
	if err := json.NewDecoder(resp.Body).Decode(&sr); err != nil {
		return nil, nil, err
	}
	if sr.Code != "200000" {
		return nil, nil, fmt.Errorf("kucoin symbols api code=%s", sr.Code)
	}

	concatToKucoin = make(map[string]string, len(sr.Data))
	kucoinToConcat = make(map[string]string, len(sr.Data))
	for _, s := range sr.Data {
		if !s.EnableTrading {
			continue
		}
		if s.BaseCurrency == "" || s.QuoteCurrency == "" || s.Symbol == "" {
			continue
		}
		concat := strings.ToUpper(s.BaseCurrency + s.QuoteCurrency)
		// На KuCoin иногда встречаются несколько рынков для одной и той же конкатенации.
		// Берём первый (обычно самый «основной»), чтобы не ломать подписку.
		if _, exists := concatToKucoin[concat]; !exists {
			concatToKucoin[concat] = s.Symbol
			kucoinToConcat[s.Symbol] = concat
		}
	}
	return concatToKucoin, kucoinToConcat, nil
}

// ==== REST: bullet-public ====

type bulletPublicResp struct {
	Code string `json:"code"`
	Data struct {
		Token           string `json:"token"`
		InstanceServers []struct {
			Endpoint     string `json:"endpoint"`
			Protocol     string `json:"protocol"`
			Encrypt      bool   `json:"encrypt"`
			PingInterval int    `json:"pingInterval"` // ms
			PingTimeout  int    `json:"pingTimeout"`  // ms
		} `json:"instanceServers"`
	} `json:"data"`
}

type wsServer struct {
	endpoint     string
	pingInterval time.Duration
	pingTimeout  time.Duration
}

func getPublicWSServer(ctx context.Context) (wsServer, string, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, "https://api.kucoin.com/api/v1/bullet-public", nil)
	if err != nil {
		return wsServer{}, "", err
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return wsServer{}, "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		b, _ := io.ReadAll(resp.Body)
		return wsServer{}, "", fmt.Errorf("kucoin bullet http %d: %s", resp.StatusCode, string(b))
	}
	var br bulletPublicResp
	if err := json.NewDecoder(resp.Body).Decode(&br); err != nil {
		return wsServer{}, "", err
	}
	if br.Code != "200000" {
		return wsServer{}, "", fmt.Errorf("kucoin bullet api code=%s", br.Code)
	}
	if br.Data.Token == "" || len(br.Data.InstanceServers) == 0 {
		return wsServer{}, "", errors.New("kucoin bullet: empty token/servers")
	}

	// Обычно достаточно первого instanceServer.
	s := br.Data.InstanceServers[0]
	pi := time.Duration(s.PingInterval) * time.Millisecond
	pt := time.Duration(s.PingTimeout) * time.Millisecond
	if pi <= 0 {
		pi = 18 * time.Second
	}
	if pt <= 0 {
		pt = 10 * time.Second
	}
	return wsServer{
		endpoint:     s.Endpoint,
		pingInterval: pi,
		pingTimeout:  pt,
	}, br.Data.Token, nil
}

func randHex(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

// ==== WS messages ====

type wsInMsg struct {
	Type    string `json:"type"`
	Topic   string `json:"topic"`
	Subject string `json:"subject"`
	Data    struct {
		BestBid     string `json:"bestBid"`
		BestAsk     string `json:"bestAsk"`
		BestBidSize string `json:"bestBidSize"`
		BestAskSize string `json:"bestAskSize"`
	} `json:"data"`
}

func parseFloat(s string) (float64, bool) {
	if s == "" {
		return 0, false
	}
	v, err := strconv.ParseFloat(s, 64)
	if err != nil || v <= 0 {
		return 0, false
	}
	return v, true
}

func (f *Feed) runTickerWS(
	ctx context.Context,
	wg *sync.WaitGroup,
	connID int,
	kuSymbols []string, // e.g. "BTC-USDT"
	interval string,
	kucoinToConcat map[string]string,
	out chan<- domain.Event,
) {
	defer wg.Done()
	_ = interval // KuCoin ticker не использует интервал; оставлено для совместимости интерфейса.

	const (
		baseRetry = 2 * time.Second
		maxRetry  = 30 * time.Second
	)

	retry := baseRetry

	for {
		select {
		case <-ctx.Done():
			return
		default:
		}

		server, token, err := getPublicWSServer(ctx)
		if err != nil {
			log.Printf("[KuCoin WS #%d] bullet-public err: %v (retry in %v)", connID, err, retry)
			time.Sleep(retry)
			retry = minDur(retry*2, maxRetry)
			continue
		}

		connectID := randHex(8)
		wsURL := fmt.Sprintf("%s?token=%s&connectId=%s", server.endpoint, token, connectID)
		conn, _, err := websocket.DefaultDialer.Dial(wsURL, nil)
		if err != nil {
			log.Printf("[KuCoin WS #%d] dial err: %v (retry in %v)", connID, err, retry)
			time.Sleep(retry)
			retry = minDur(retry*2, maxRetry)
			continue
		}
		log.Printf("[KuCoin WS #%d] connected (symbols: %d)", connID, len(kuSymbols))
		retry = baseRetry

		// Read deadline = pingInterval + pingTimeout (чтобы не зависать навечно).
		readDeadline := time.Now().Add(server.pingInterval + server.pingTimeout)
		_ = conn.SetReadDeadline(readDeadline)

		stopPing := make(chan struct{})
		go func() {
			t := time.NewTicker(server.pingInterval)
			defer t.Stop()
			for {
				select {
				case <-t.C:
					msg := map[string]any{"id": randHex(6), "type": "ping"}
					_ = conn.SetWriteDeadline(time.Now().Add(5 * time.Second))
					if err := conn.WriteJSON(msg); err != nil {
						f.dlog("[KuCoin WS #%d] ping error: %v", connID, err)
						return
					}
				case <-stopPing:
					return
				case <-ctx.Done():
					return
				}
			}
		}()

		// Subscribe (response=true, чтобы получить ack).
		subOK := true
		for _, sym := range kuSymbols {
			sub := map[string]any{
				"id":             randHex(6),
				"type":           "subscribe",
				"topic":          "/market/ticker:" + sym,
				"privateChannel": false,
				"response":       true,
			}
			_ = conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if err := conn.WriteJSON(sub); err != nil {
				log.Printf("[KuCoin WS #%d] subscribe send err: %v", connID, err)
				subOK = false
				break
			}
		}
		if !subOK {
			close(stopPing)
			_ = conn.Close()
			time.Sleep(retry)
			retry = minDur(retry*2, maxRetry)
			continue
		}
		log.Printf("[KuCoin WS #%d] SUB -> %d topics", connID, len(kuSymbols))

		// Read loop
		for {
			mt, raw, err := conn.ReadMessage()
			if err != nil {
				log.Printf("[KuCoin WS #%d] read err: %v (reconnect)", connID, err)
				break
			}
			if mt != websocket.TextMessage {
				continue
			}

			// обновляем дедлайн после каждого сообщения
			_ = conn.SetReadDeadline(time.Now().Add(server.pingInterval + server.pingTimeout))

			if f.debug {
				f.dlog("[KuCoin #%d RAW] %s", connID, string(raw))
			}

			var m wsInMsg
			if err := json.Unmarshal(raw, &m); err != nil {
				continue
			}
			if m.Type != "message" {
				// welcome / ack / pong и т.д.
				continue
			}
			if !strings.HasPrefix(m.Topic, "/market/ticker:") {
				continue
			}
			kuSym := strings.TrimPrefix(m.Topic, "/market/ticker:")
			concat, ok := kucoinToConcat[kuSym]
			if !ok {
				// иногда символ может прийти в другом виде — попробуем нормализовать
				concat = strings.ReplaceAll(strings.ToUpper(kuSym), "-", "")
			}

			bid, ok1 := parseFloat(m.Data.BestBid)
			ask, ok2 := parseFloat(m.Data.BestAsk)
			if !ok1 || !ok2 {
				continue
			}

			var bidQty, askQty float64
			if v, ok := parseFloat(m.Data.BestBidSize); ok {
				bidQty = v
			}
			if v, ok := parseFloat(m.Data.BestAskSize); ok {
				askQty = v
			}

			ev := domain.Event{Symbol: concat, Bid: bid, Ask: ask, BidQty: bidQty, AskQty: askQty}
			select {
			case out <- ev:
			case <-ctx.Done():
				close(stopPing)
				_ = conn.Close()
				return
			}
		}

		close(stopPing)
		_ = conn.Close()
		time.Sleep(retry)
		retry = minDur(retry*2, maxRetry)
	}
}

func minDur(a, b time.Duration) time.Duration {
	if a < b {
		return a
	}
	return b
}

// Start реализует интерфейс MarketDataFeed.
func (f *Feed) Start(
	ctx context.Context,
	wg *sync.WaitGroup,
	symbols []string,
	interval string,
	out chan<- domain.Event,
) {
	// 1) Собираем маппинг (concat <-> KuCoin symbol)
	concatToKucoin, kucoinToConcat, err := loadSpotSymbolsMap(ctx)
	if err != nil {
		log.Printf("[KuCoin] WARNING: cannot load symbols map: %v (будем пытаться угадать формат)", err)
		concatToKucoin = map[string]string{}
		kucoinToConcat = map[string]string{}
	}

	kuSymbols := make([]string, 0, len(symbols))
	missing := 0
	for _, s := range symbols {
		s = strings.ToUpper(strings.TrimSpace(s))
		if s == "" {
			continue
		}
		if ks, ok := concatToKucoin[s]; ok {
			kuSymbols = append(kuSymbols, ks)
			continue
		}
		// fallback: если вход уже похож на "BASE-QUOTE".
		if strings.Contains(s, "-") {
			kuSymbols = append(kuSymbols, s)
			kucoinToConcat[s] = strings.ReplaceAll(strings.ToUpper(s), "-", "")
			continue
		}
		missing++
	}

	if len(kuSymbols) == 0 {
		log.Printf("[KuCoin] no symbols to subscribe (input=%d, missing=%d)", len(symbols), missing)
		return
	}
	if missing > 0 {
		log.Printf("[KuCoin] symbols missing in map: %d (будут пропущены)", missing)
	}

	// 2) Разбиваем на несколько соединений (меньше риск лимитов/разрывов)
	const maxPerConn = 80
	chunks := make([][]string, 0)
	for i := 0; i < len(kuSymbols); i += maxPerConn {
		j := i + maxPerConn
		if j > len(kuSymbols) {
			j = len(kuSymbols)
		}
		chunks = append(chunks, kuSymbols[i:j])
	}
	log.Printf("[KuCoin] будем использовать %d WS-подключений", len(chunks))

	for idx, chunk := range chunks {
		wg.Add(1)
		go f.runTickerWS(ctx, wg, idx, chunk, interval, kucoinToConcat, out)
	}
}
