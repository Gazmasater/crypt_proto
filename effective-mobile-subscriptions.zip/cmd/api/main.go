package main

import (
    "context"
    "log/slog"
    "net/http"
    "os"
    "os/signal"
    "syscall"
    "time"

    "github.com/effectivemobile/test-subscriptions/internal/app"
    "github.com/effectivemobile/test-subscriptions/internal/config"
)

func main() {
    cfg, err := config.Load()
    if err != nil {
        panic(err)
    }

    logger := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{
        Level: cfg.Log.Level(),
    }))
    slog.SetDefault(logger)

    a, err := app.New(cfg)
    if err != nil {
        logger.Error("init app", "err", err)
        os.Exit(1)
    }

    srv := &http.Server{
        Addr:         cfg.HTTP.Addr,
        Handler:      a.Router(),
        ReadTimeout:  cfg.HTTP.ReadTimeout,
        WriteTimeout: cfg.HTTP.WriteTimeout,
        IdleTimeout:  60 * time.Second,
    }

    go func() {
        logger.Info("http server started", "addr", cfg.HTTP.Addr)
        if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
            logger.Error("http server error", "err", err)
            os.Exit(1)
        }
    }()

    stop := make(chan os.Signal, 1)
    signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
    <-stop
    logger.Info("shutdown signal received")

    ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
    defer cancel()

    if err := srv.Shutdown(ctx); err != nil {
        logger.Error("http shutdown error", "err", err)
    }
    a.Close()
    logger.Info("shutdown complete")
}
