DROP TABLE IF EXISTS subscriptions;
