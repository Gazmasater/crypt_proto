# Subscriptions Aggregator (Effective Mobile тестовое)

REST-сервис для CRUDL-операций над подписками и расчёта суммарной стоимости подписок за период.

## Запуск

```bash
docker compose up --build
```

Сервис будет доступен на `http://localhost:8080`.

## Swagger

- UI: `http://localhost:8080/swagger`
- OpenAPI YAML: `http://localhost:8080/swagger/openapi.yaml`

## Основные ручки

- `POST /v1/subscriptions` — создать
- `GET /v1/subscriptions/{id}` — получить
- `PATCH /v1/subscriptions/{id}` — частично обновить
- `DELETE /v1/subscriptions/{id}` — удалить
- `GET /v1/subscriptions?user_id=&service_name=&limit=&offset=` — список
- `GET /v1/subscriptions/total?from=MM-YYYY&to=MM-YYYY&user_id=&service_name=` — сумма за период

### Пример создания

```bash
curl -X POST http://localhost:8080/v1/subscriptions \
  -H 'Content-Type: application/json' \
  -d '{
    "service_name":"Yandex Plus",
    "price":400,
    "user_id":"60601fee-2bf1-4721-ae6f-7636e79a0cba",
    "start_date":"07-2025"
  }'
```

## Модель хранения дат

`start_date` и `end_date` хранятся в PostgreSQL как `DATE` с нормализацией к первому дню месяца (например, `"07-2025"` -> `2025-07-01`).

## Миграции

При старте сервиса автоматически применяются `migrations/*_*.up.sql`, прогресс фиксируется в таблице `schema_migrations`.
