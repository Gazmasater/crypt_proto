package app

import (
    "context"
    "net/http"
    "time"

    "github.com/effectivemobile/test-subscriptions/internal/config"
    "github.com/effectivemobile/test-subscriptions/internal/httpapi"
    "github.com/effectivemobile/test-subscriptions/internal/migrate"
    "github.com/effectivemobile/test-subscriptions/internal/storage"
    "github.com/jackc/pgx/v5/pgxpool"
    "log/slog"
)

type App struct {
    cfg   *config.Config
    pool  *pgxpool.Pool
    store *storage.Store
    api   *httpapi.API
}

func New(cfg *config.Config) (*App, error) {
    ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
    defer cancel()

    pool, err := pgxpool.New(ctx, cfg.DB.DSN)
    if err != nil {
        return nil, err
    }
    if err := pool.Ping(ctx); err != nil {
        pool.Close()
        return nil, err
    }

    // migrations
    if err := migrate.EnsureDir(cfg.Migrations.Dir); err != nil {
        pool.Close()
        return nil, err
    }
    if err := migrate.New(pool, cfg.Migrations.Dir).Up(ctx); err != nil {
        pool.Close()
        return nil, err
    }
    slog.Info("migrations applied", "dir", cfg.Migrations.Dir)

    store := storage.New(pool)
    api := httpapi.New(store)

    return &App{cfg: cfg, pool: pool, store: store, api: api}, nil
}

func (a *App) Router() http.Handler { return a.api.Router() }

func (a *App) Close() {
    if a.store != nil {
        a.store.Close()
    }
}
