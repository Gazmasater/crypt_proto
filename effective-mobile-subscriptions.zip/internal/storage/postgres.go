package storage

import (
    "context"
    "errors"
    "fmt"
    "time"

    "github.com/effectivemobile/test-subscriptions/internal/models"
    "github.com/google/uuid"
    "github.com/jackc/pgx/v5"
    "github.com/jackc/pgx/v5/pgxpool"
)

var ErrNotFound = errors.New("not found")

type Store struct {
    pool *pgxpool.Pool
}

func New(pool *pgxpool.Pool) *Store {
    return &Store{pool: pool}
}

func (s *Store) Close() {
    if s.pool != nil {
        s.pool.Close()
    }
}

func (s *Store) CreateSubscription(ctx context.Context, sub *models.Subscription) error {
    q := `INSERT INTO subscriptions (id, service_name, price_rub, user_id, start_date, end_date)
          VALUES ($1,$2,$3,$4,$5,$6)`
    _, err := s.pool.Exec(ctx, q, sub.ID, sub.ServiceName, sub.Price, sub.UserID, sub.StartDate, sub.EndDate)
    return err
}

func (s *Store) GetSubscription(ctx context.Context, id uuid.UUID) (models.Subscription, error) {
    q := `SELECT id, service_name, price_rub, user_id, start_date, end_date, created_at, updated_at
          FROM subscriptions WHERE id=$1`
    var sub models.Subscription
    err := s.pool.QueryRow(ctx, q, id).Scan(
        &sub.ID, &sub.ServiceName, &sub.Price, &sub.UserID, &sub.StartDate, &sub.EndDate, &sub.CreatedAt, &sub.UpdatedAt,
    )
    if errors.Is(err, pgx.ErrNoRows) {
        return models.Subscription{}, ErrNotFound
    }
    return sub, err
}

func (s *Store) DeleteSubscription(ctx context.Context, id uuid.UUID) error {
    q := `DELETE FROM subscriptions WHERE id=$1`
    ct, err := s.pool.Exec(ctx, q, id)
    if err != nil {
        return err
    }
    if ct.RowsAffected() == 0 {
        return ErrNotFound
    }
    return nil
}

type ListFilter struct {
    UserID      *uuid.UUID
    ServiceName *string
    Limit       int
    Offset      int
}

func (s *Store) ListSubscriptions(ctx context.Context, f ListFilter) ([]models.Subscription, int, error) {
    where := "WHERE 1=1"
    args := []any{}
    n := 0
    if f.UserID != nil {
        n++
        where += fmt.Sprintf(" AND user_id=$%d", n)
        args = append(args, *f.UserID)
    }
    if f.ServiceName != nil {
        n++
        where += fmt.Sprintf(" AND service_name=$%d", n)
        args = append(args, *f.ServiceName)
    }

    // total
    tq := `SELECT COUNT(*) FROM subscriptions ` + where
    var total int
    if err := s.pool.QueryRow(ctx, tq, args...).Scan(&total); err != nil {
        return nil, 0, err
    }

    n++
    args = append(args, f.Limit)
    limitArg := n
    n++
    args = append(args, f.Offset)
    offsetArg := n

    q := fmt.Sprintf(`SELECT id, service_name, price_rub, user_id, start_date, end_date, created_at, updated_at
                      FROM subscriptions %s
                      ORDER BY created_at DESC
                      LIMIT $%d OFFSET $%d`, where, limitArg, offsetArg)

    rows, err := s.pool.Query(ctx, q, args...)
    if err != nil {
        return nil, 0, err
    }
    defer rows.Close()

    items := []models.Subscription{}
    for rows.Next() {
        var sub models.Subscription
        if err := rows.Scan(&sub.ID, &sub.ServiceName, &sub.Price, &sub.UserID, &sub.StartDate, &sub.EndDate, &sub.CreatedAt, &sub.UpdatedAt); err != nil {
            return nil, 0, err
        }
        items = append(items, sub)
    }
    if rows.Err() != nil {
        return nil, 0, rows.Err()
    }
    return items, total, nil
}

type UpdatePatch struct {
    ServiceName *string
    Price       *int
    UserID      *uuid.UUID
    StartDate   *time.Time
    EndDate     *time.Time // nil means set NULL; use hasEndDate flag to know if field present
    HasEndDate  bool
}

func (s *Store) UpdateSubscription(ctx context.Context, id uuid.UUID, p UpdatePatch) (models.Subscription, error) {
    // Fetch current
    cur, err := s.GetSubscription(ctx, id)
    if err != nil {
        return models.Subscription{}, err
    }
    if p.ServiceName != nil {
        cur.ServiceName = *p.ServiceName
    }
    if p.Price != nil {
        cur.Price = *p.Price
    }
    if p.UserID != nil {
        cur.UserID = *p.UserID
    }
    if p.StartDate != nil {
        cur.StartDate = *p.StartDate
    }
    if p.HasEndDate {
        cur.EndDate = p.EndDate
    }

    q := `UPDATE subscriptions
          SET service_name=$2, price_rub=$3, user_id=$4, start_date=$5, end_date=$6, updated_at=now()
          WHERE id=$1`
    ct, err := s.pool.Exec(ctx, q, cur.ID, cur.ServiceName, cur.Price, cur.UserID, cur.StartDate, cur.EndDate)
    if err != nil {
        return models.Subscription{}, err
    }
    if ct.RowsAffected() == 0 {
        return models.Subscription{}, ErrNotFound
    }
    return s.GetSubscription(ctx, id)
}

type TotalFilter struct {
    From        time.Time
    To          time.Time
    UserID      *uuid.UUID
    ServiceName *string
}

func (s *Store) TotalCost(ctx context.Context, f TotalFilter) (int, error) {
    // inclusive month interval [from, to]
    where := "WHERE 1=1"
    args := []any{}
    n := 0

    // overlap condition
    n++
    fromArg := n
    args = append(args, f.From)
    n++
    toArg := n
    args = append(args, f.To)

    where += fmt.Sprintf(` AND start_date <= $%d AND COALESCE(end_date, $%d) >= $%d`, toArg, toArg, fromArg)

    if f.UserID != nil {
        n++
        where += fmt.Sprintf(" AND user_id=$%d", n)
        args = append(args, *f.UserID)
    }
    if f.ServiceName != nil {
        n++
        where += fmt.Sprintf(" AND service_name=$%d", n)
        args = append(args, *f.ServiceName)
    }

    q := fmt.Sprintf(`
WITH bounds AS (
  SELECT
    GREATEST(date_trunc('month', start_date), date_trunc('month', $%d)) AS os,
    LEAST(date_trunc('month', COALESCE(end_date, $%d)), date_trunc('month', $%d)) AS oe,
    price_rub
  FROM subscriptions
  %s
),
months AS (
  SELECT
    price_rub,
    ((EXTRACT(YEAR FROM oe)::int * 12 + EXTRACT(MONTH FROM oe)::int)
     - (EXTRACT(YEAR FROM os)::int * 12 + EXTRACT(MONTH FROM os)::int)
     + 1) AS m
  FROM bounds
)
SELECT COALESCE(SUM(price_rub * GREATEST(m,0)), 0) FROM months;
`, fromArg, toArg, toArg, where)

    var total int
    err := s.pool.QueryRow(ctx, q, args...).Scan(&total)
    return total, err
}
