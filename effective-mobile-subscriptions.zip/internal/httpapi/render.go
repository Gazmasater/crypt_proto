package httpapi

import (
    "encoding/json"
    "net/http"
)

type APIError struct {
    Error string `json:"error"`
}

func writeJSON(w http.ResponseWriter, status int, v any) {
    w.Header().Set("Content-Type", "application/json; charset=utf-8")
    w.WriteHeader(status)
    _ = json.NewEncoder(w).Encode(v)
}

func badRequest(w http.ResponseWriter, msg string) {
    writeJSON(w, http.StatusBadRequest, APIError{Error: msg})
}

func notFound(w http.ResponseWriter) {
    writeJSON(w, http.StatusNotFound, APIError{Error: "not found"})
}
