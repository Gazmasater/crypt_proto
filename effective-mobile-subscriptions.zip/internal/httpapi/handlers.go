package httpapi

import (
    "encoding/json"
    "errors"
    "net/http"
    "strconv"
    "strings"
    "time"

    "github.com/effectivemobile/test-subscriptions/internal/models"
    "github.com/effectivemobile/test-subscriptions/internal/storage"
    "github.com/effectivemobile/test-subscriptions/internal/timeutil"
    "github.com/go-chi/chi/v5"
    "github.com/google/uuid"
    "log/slog"
)

func (a *API) createSubscription(w http.ResponseWriter, r *http.Request) {
    var req models.CreateSubscriptionRequest
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        badRequest(w, "invalid json")
        return
    }
    req.ServiceName = strings.TrimSpace(req.ServiceName)
    if req.ServiceName == "" {
        badRequest(w, "service_name is required")
        return
    }
    if req.Price < 0 {
        badRequest(w, "price must be >= 0")
        return
    }
    if req.UserID == uuid.Nil {
        badRequest(w, "user_id is required")
        return
    }

    sd, err := timeutil.ParseMonthYear(req.StartDate)
    if err != nil {
        badRequest(w, err.Error())
        return
    }
    var ed *string = req.EndDate
    var endDatePtr *time.Time
    if ed != nil {
        t, err := timeutil.ParseMonthYear(*ed)
        if err != nil {
            badRequest(w, err.Error())
            return
        }
        endDatePtr = &t
    }

    sub := models.Subscription{
        ID:          uuid.New(),
        ServiceName: req.ServiceName,
        Price:       req.Price,
        UserID:      req.UserID,
        StartDate:   sd,
        EndDate:     endDatePtr,
    }

    if endDatePtr != nil && endDatePtr.Before(sd) {
        badRequest(w, "end_date must be >= start_date")
        return
    }

    if err := a.store.CreateSubscription(r.Context(), &sub); err != nil {
        slog.Error("create subscription", "err", err)
        writeJSON(w, http.StatusInternalServerError, APIError{Error: "internal error"})
        return
    }
    // return full object
    created, err := a.store.GetSubscription(r.Context(), sub.ID)
    if err != nil {
        slog.Error("get created subscription", "err", err)
        writeJSON(w, http.StatusInternalServerError, APIError{Error: "internal error"})
        return
    }
    writeJSON(w, http.StatusCreated, created)
}

func (a *API) getSubscription(w http.ResponseWriter, r *http.Request) {
    id, err := uuid.Parse(chi.URLParam(r, "id"))
    if err != nil {
        badRequest(w, "invalid id")
        return
    }
    sub, err := a.store.GetSubscription(r.Context(), id)
    if errors.Is(err, storage.ErrNotFound) {
        notFound(w)
        return
    }
    if err != nil {
        slog.Error("get subscription", "err", err)
        writeJSON(w, http.StatusInternalServerError, APIError{Error: "internal error"})
        return
    }
    writeJSON(w, http.StatusOK, sub)
}

func (a *API) deleteSubscription(w http.ResponseWriter, r *http.Request) {
    id, err := uuid.Parse(chi.URLParam(r, "id"))
    if err != nil {
        badRequest(w, "invalid id")
        return
    }
    if err := a.store.DeleteSubscription(r.Context(), id); errors.Is(err, storage.ErrNotFound) {
        notFound(w)
        return
    } else if err != nil {
        slog.Error("delete subscription", "err", err)
        writeJSON(w, http.StatusInternalServerError, APIError{Error: "internal error"})
        return
    }
    w.WriteHeader(http.StatusNoContent)
}

func (a *API) listSubscriptions(w http.ResponseWriter, r *http.Request) {
    q := r.URL.Query()

    var userID *uuid.UUID
    if v := strings.TrimSpace(q.Get("user_id")); v != "" {
        id, err := uuid.Parse(v)
        if err != nil {
            badRequest(w, "invalid user_id")
            return
        }
        userID = &id
    }
    var serviceName *string
    if v := strings.TrimSpace(q.Get("service_name")); v != "" {
        serviceName = &v
    }
    limit := 50
    offset := 0
    if v := q.Get("limit"); v != "" {
        n, err := strconv.Atoi(v)
        if err != nil || n < 1 || n > 200 {
            badRequest(w, "limit must be 1..200")
            return
        }
        limit = n
    }
    if v := q.Get("offset"); v != "" {
        n, err := strconv.Atoi(v)
        if err != nil || n < 0 {
            badRequest(w, "offset must be >= 0")
            return
        }
        offset = n
    }

    items, total, err := a.store.ListSubscriptions(r.Context(), storage.ListFilter{
        UserID:      userID,
        ServiceName: serviceName,
        Limit:       limit,
        Offset:      offset,
    })
    if err != nil {
        slog.Error("list subscriptions", "err", err)
        writeJSON(w, http.StatusInternalServerError, APIError{Error: "internal error"})
        return
    }
    writeJSON(w, http.StatusOK, models.ListSubscriptionsResponse{Items: items, Total: total})
}

func (a *API) updateSubscription(w http.ResponseWriter, r *http.Request) {
    id, err := uuid.Parse(chi.URLParam(r, "id"))
    if err != nil {
        badRequest(w, "invalid id")
        return
    }

    // To distinguish "end_date omitted" vs "end_date: null", use RawMessage map.
    var raw map[string]json.RawMessage
    if err := json.NewDecoder(r.Body).Decode(&raw); err != nil {
        badRequest(w, "invalid json")
        return
    }

    patch := storage.UpdatePatch{}

    if v, ok := raw["service_name"]; ok {
        var s string
        if err := json.Unmarshal(v, &s); err != nil {
            badRequest(w, "service_name must be string")
            return
        }
        s = strings.TrimSpace(s)
        if s == "" {
            badRequest(w, "service_name cannot be empty")
            return
        }
        patch.ServiceName = &s
    }
    if v, ok := raw["price"]; ok {
        var p int
        if err := json.Unmarshal(v, &p); err != nil {
            badRequest(w, "price must be int")
            return
        }
        if p < 0 {
            badRequest(w, "price must be >= 0")
            return
        }
        patch.Price = &p
    }
    if v, ok := raw["user_id"]; ok {
        var s string
        if err := json.Unmarshal(v, &s); err != nil {
            badRequest(w, "user_id must be uuid string")
            return
        }
        uid, err := uuid.Parse(s)
        if err != nil || uid == uuid.Nil {
            badRequest(w, "invalid user_id")
            return
        }
        patch.UserID = &uid
    }
    if v, ok := raw["start_date"]; ok {
        var s string
        if err := json.Unmarshal(v, &s); err != nil {
            badRequest(w, "start_date must be string")
            return
        }
        t, err := timeutil.ParseMonthYear(s)
        if err != nil {
            badRequest(w, err.Error())
            return
        }
        patch.StartDate = &t
    }
    if v, ok := raw["end_date"]; ok {
        patch.HasEndDate = true
        // null -> set NULL
        if string(v) == "null" {
            patch.EndDate = nil
        } else {
            var s string
            if err := json.Unmarshal(v, &s); err != nil {
                badRequest(w, "end_date must be string or null")
                return
            }
            t, err := timeutil.ParseMonthYear(s)
            if err != nil {
                badRequest(w, err.Error())
                return
            }
            patch.EndDate = &t
        }
    }

    // basic cross-field validation by re-reading updated entity in store
    updated, err := a.store.UpdateSubscription(r.Context(), id, patch)
    if errors.Is(err, storage.ErrNotFound) {
        notFound(w)
        return
    }
    if err != nil {
        slog.Error("update subscription", "err", err)
        writeJSON(w, http.StatusInternalServerError, APIError{Error: "internal error"})
        return
    }
    writeJSON(w, http.StatusOK, updated)
}

func (a *API) totalCost(w http.ResponseWriter, r *http.Request) {
    q := r.URL.Query()
    fromStr := strings.TrimSpace(q.Get("from"))
    toStr := strings.TrimSpace(q.Get("to"))
    if fromStr == "" || toStr == "" {
        badRequest(w, "from and to are required in MM-YYYY")
        return
    }
    from, err := timeutil.ParseMonthYear(fromStr)
    if err != nil {
        badRequest(w, err.Error())
        return
    }
    to, err := timeutil.ParseMonthYear(toStr)
    if err != nil {
        badRequest(w, err.Error())
        return
    }
    if to.Before(from) {
        badRequest(w, "to must be >= from")
        return
    }

    var userID *uuid.UUID
    if v := strings.TrimSpace(q.Get("user_id")); v != "" {
        id, err := uuid.Parse(v)
        if err != nil {
            badRequest(w, "invalid user_id")
            return
        }
        userID = &id
    }
    var serviceName *string
    if v := strings.TrimSpace(q.Get("service_name")); v != "" {
        serviceName = &v
    }

    total, err := a.store.TotalCost(r.Context(), storage.TotalFilter{
        From:        from,
        To:          to,
        UserID:      userID,
        ServiceName: serviceName,
    })
    if err != nil {
        slog.Error("total cost", "err", err)
        writeJSON(w, http.StatusInternalServerError, APIError{Error: "internal error"})
        return
    }
    writeJSON(w, http.StatusOK, models.TotalCostResponse{TotalRub: total})
}
