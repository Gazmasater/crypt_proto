package httpapi

import (
    "embed"
    "net/http"
    "os"
)

//go:embed swagger/index.html
var swaggerFS embed.FS

func (a *API) serveOpenAPI(w http.ResponseWriter, r *http.Request) {
    // Try local file first (works in docker image and local dev)
    b, err := os.ReadFile("openapi.yaml")
    if err != nil {
        // dockerfile also copies to /app/openapi.yaml, but if workdir differs:
        b, err = os.ReadFile("/app/openapi.yaml")
    }
    if err != nil {
        w.WriteHeader(http.StatusInternalServerError)
        return
    }

    w.Header().Set("Content-Type", "application/yaml; charset=utf-8")
    w.WriteHeader(http.StatusOK)
    _, _ = w.Write(b)
}

func (a *API) serveSwaggerUI(w http.ResponseWriter, r *http.Request) {
    b, err := swaggerFS.ReadFile("swagger/index.html")
    if err != nil {
        w.WriteHeader(http.StatusInternalServerError)
        return
    }
    w.Header().Set("Content-Type", "text/html; charset=utf-8")
    w.WriteHeader(http.StatusOK)
    _, _ = w.Write(b)
}
