package httpapi

import (
    "net/http"

    "github.com/effectivemobile/test-subscriptions/internal/storage"
    "github.com/go-chi/chi/v5"
    "github.com/go-chi/chi/v5/middleware"
)

type API struct {
    store *storage.Store
}

func New(store *storage.Store) *API {
    return &API{store: store}
}

func (a *API) Router() http.Handler {
    r := chi.NewRouter()

    r.Use(middleware.RequestID)
    r.Use(middleware.RealIP)
    r.Use(middleware.Recoverer)
    r.Use(middleware.Timeout(15))
    r.Use(middleware.Compress(5))
    r.Use(accessLogMiddleware)

    r.Get("/healthz", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusOK) })

    // swagger
    r.Get("/swagger/openapi.yaml", a.serveOpenAPI)
    r.Get("/swagger", a.serveSwaggerUI)

    r.Route("/v1", func(r chi.Router) {
        r.Route("/subscriptions", func(r chi.Router) {
            r.Post("/", a.createSubscription)
            r.Get("/", a.listSubscriptions)
            r.Get("/{id}", a.getSubscription)
            r.Patch("/{id}", a.updateSubscription)
            r.Delete("/{id}", a.deleteSubscription)
        })
        r.Get("/subscriptions/total", a.totalCost)
    })

    return r
}
