package migrate

import (
    "context"
    "crypto/sha256"
    "encoding/hex"
    "fmt"
    "io/fs"
    "os"
    "path/filepath"
    "sort"
    "strings"
    "time"

    "github.com/jackc/pgx/v5"
    "github.com/jackc/pgx/v5/pgxpool"
)

type Migrator struct {
    pool *pgxpool.Pool
    dir  string
}

func New(pool *pgxpool.Pool, dir string) *Migrator {
    return &Migrator{pool: pool, dir: dir}
}

func (m *Migrator) Up(ctx context.Context) error {
    // migrations table
    _, err := m.pool.Exec(ctx, `
CREATE TABLE IF NOT EXISTS schema_migrations (
    version TEXT PRIMARY KEY,
    checksum TEXT NOT NULL,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
);`)
    if err != nil {
        return err
    }

    files, err := filepath.Glob(filepath.Join(m.dir, "*_*.up.sql"))
    if err != nil {
        return err
    }
    sort.Strings(files)

    for _, path := range files {
        base := filepath.Base(path)               // 001_init.up.sql
        version := strings.Split(base, ".")[0]    // 001_init
        b, err := os.ReadFile(path)
        if err != nil {
            return fmt.Errorf("read migration %s: %w", base, err)
        }
        sum := sha256.Sum256(b)
        checksum := hex.EncodeToString(sum[:])

        var exists bool
        var existingChecksum string
        err = m.pool.QueryRow(ctx, `SELECT true, checksum FROM schema_migrations WHERE version=$1`, version).Scan(&exists, &existingChecksum)
        if err != nil {
            if err == pgx.ErrNoRows {
                exists = false
            } else {
                return err
            }
        }
        if exists {
            if existingChecksum != checksum {
                return fmt.Errorf("migration %s checksum mismatch: have %s, want %s", version, existingChecksum, checksum)
            }
            continue
        }

        // apply in tx
        tx, err := m.pool.Begin(ctx)
        if err != nil {
            return err
        }
        if _, err := tx.Exec(ctx, string(b)); err != nil {
            _ = tx.Rollback(ctx)
            return fmt.Errorf("apply migration %s: %w", base, err)
        }
        if _, err := tx.Exec(ctx, `INSERT INTO schema_migrations(version, checksum, applied_at) VALUES ($1,$2,$3)`,
            version, checksum, time.Now().UTC()); err != nil {
            _ = tx.Rollback(ctx)
            return err
        }
        if err := tx.Commit(ctx); err != nil {
            return err
        }
    }
    return nil
}

// EnsureDir checks migration dir exists (useful for docker images).
func EnsureDir(dir string) error {
    st, err := os.Stat(dir)
    if err != nil {
        return err
    }
    if !st.IsDir() {
        return fs.ErrInvalid
    }
    return nil
}
