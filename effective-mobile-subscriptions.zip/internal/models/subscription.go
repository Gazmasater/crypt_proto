package models

import (
    "time"

    "github.com/google/uuid"
)

type Subscription struct {
    ID          uuid.UUID  `json:"id"`
    ServiceName string     `json:"service_name"`
    Price       int        `json:"price"`
    UserID      uuid.UUID  `json:"user_id"`
    StartDate   time.Time  `json:"start_date"` // stored as first day of month (UTC)
    EndDate     *time.Time `json:"end_date,omitempty"`
    CreatedAt   time.Time  `json:"created_at"`
    UpdatedAt   time.Time  `json:"updated_at"`
}

type CreateSubscriptionRequest struct {
    ServiceName string    `json:"service_name"`
    Price       int       `json:"price"`
    UserID      uuid.UUID `json:"user_id"`
    StartDate   string    `json:"start_date"`           // "MM-YYYY"
    EndDate     *string   `json:"end_date,omitempty"`   // "MM-YYYY"
}

type UpdateSubscriptionRequest struct {
    ServiceName *string   `json:"service_name,omitempty"`
    Price       *int      `json:"price,omitempty"`
    UserID      *uuid.UUID `json:"user_id,omitempty"`
    StartDate   *string   `json:"start_date,omitempty"` // "MM-YYYY"
    EndDate     **string  `json:"end_date,omitempty"`   // nil=absent, &nil=set null, &".." set value
}

type ListSubscriptionsResponse struct {
    Items []Subscription `json:"items"`
    Total int            `json:"total"`
}

type TotalCostResponse struct {
    TotalRub int `json:"total_rub"`
}
