package config

import (
    "errors"
    "fmt"
    "log/slog"
    "os"
    "time"

    "github.com/joho/godotenv"
)

type HTTPConfig struct {
    Addr         string
    ReadTimeout  time.Duration
    WriteTimeout time.Duration
}

type DBConfig struct {
    DSN string
}

type LogConfig struct {
    LevelStr string
}

func (l LogConfig) Level() slog.Leveler {
    switch l.LevelStr {
    case "debug":
        return slog.LevelDebug
    case "warn":
        return slog.LevelWarn
    case "error":
        return slog.LevelError
    default:
        return slog.LevelInfo
    }
}

type MigrationsConfig struct {
    Dir string
}

type Config struct {
    HTTP       HTTPConfig
    DB         DBConfig
    Log        LogConfig
    Migrations MigrationsConfig
}

func Load() (*Config, error) {
    // .env is optional in docker (compose passes env), but useful locally.
    _ = godotenv.Load()

    cfg := &Config{}
    cfg.HTTP.Addr = getenv("HTTP_ADDR", ":8080")
    cfg.HTTP.ReadTimeout = getenvDuration("HTTP_READ_TIMEOUT", 10*time.Second)
    cfg.HTTP.WriteTimeout = getenvDuration("HTTP_WRITE_TIMEOUT", 10*time.Second)

    cfg.DB.DSN = getenv("DB_DSN", "")
    if cfg.DB.DSN == "" {
        host := getenv("DB_HOST", "postgres")
        port := getenv("DB_PORT", "5432")
        user := getenv("DB_USER", "postgres")
        pass := getenv("DB_PASSWORD", "postgres")
        name := getenv("DB_NAME", "subscriptions")
        sslmode := getenv("DB_SSLMODE", "disable")
        cfg.DB.DSN = fmt.Sprintf("postgres://%s:%s@%s:%s/%s?sslmode=%s", user, pass, host, port, name, sslmode)
    }

    cfg.Log.LevelStr = getenv("LOG_LEVEL", "info")
    cfg.Migrations.Dir = getenv("MIGRATIONS_DIR", "migrations")

    if cfg.HTTP.Addr == "" {
        return nil, errors.New("HTTP_ADDR is empty")
    }
    return cfg, nil
}

func getenv(key, def string) string {
    v := os.Getenv(key)
    if v == "" {
        return def
    }
    return v
}

func getenvDuration(key string, def time.Duration) time.Duration {
    v := os.Getenv(key)
    if v == "" {
        return def
    }
    d, err := time.ParseDuration(v)
    if err != nil {
        return def
    }
    return d
}
